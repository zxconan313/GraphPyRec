PANEL_DASHBOARD = 'project'
PANEL_GROUP = 'default'
PANEL = 'api_access'

ADD_PANEL = \
    ('openstack_dashboard.dashboards.project.api_access.panel.ApiAccess')
