def a_method():
    pass


class AClass:
    pass


var = "A Variable"

print("Support library name: {}".format(__name__))

if __name__ == '__main__':
    age = 0
    while age <= 0:
        age = int(input("How old are you? "))
