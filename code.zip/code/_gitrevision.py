#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "5f7a95608f"  # abbreviated commit hash
commit = "5f7a95608f85f5a0a428a3ea842338eb8e9ac4df"  # commit hash
date = "2022-03-24 08:04:38 +0000"  # commit date
author = "Starbuck5 <46412508+Starbuck5@users.noreply.github.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Remove unused link stubs
"""
