# @dependency 001-main/005-unittests/001-local/001-independence.py
# @flag local

# These tests simply check that some modules can be imported.

instance.unittest("operation.basictypes", ["basic"])
instance.unittest("operation.typechecker", ["basic"])
