def get_user(request): pass

login_url = "/login"
