x = 7
y = 11

print("x={}, y={}".format(x, y))

# swap: nonpythonic
# temp = x
# x = y
# y = temp

y, x = x, y

print("x={}, y={}".format(x, y))
