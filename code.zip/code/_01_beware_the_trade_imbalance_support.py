def mode(*args):
    if not args:
        print("Mode set to DEFAULT")
        return

    print("Mode set to ADVANCED")
