# Start instance and install (and upgrade, optionally) Critic with the default
# arguments.
instance.start()
instance.install(repository)
instance.upgrade()
