PANEL_DASHBOARD = 'project'
PANEL_GROUP = 'compute'
PANEL = 'key_pairs'

ADD_PANEL = 'openstack_dashboard.dashboards.project.key_pairs.panel.KeyPairs'
