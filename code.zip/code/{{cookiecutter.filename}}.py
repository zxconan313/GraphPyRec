"""Sample file to be created through a cookiecutter run."""

print("These are the contents of {{ cookiecutter.filename }}.py.")
