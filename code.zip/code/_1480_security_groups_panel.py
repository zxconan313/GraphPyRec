PANEL_DASHBOARD = 'project'
PANEL_GROUP = 'network'
PANEL = 'security_groups'

ADD_PANEL = ('openstack_dashboard.dashboards.project.security_groups'
             '.panel.SecurityGroups')
