# Tutorial 0: Introduction

################
# Executing code

# To execute code in FoxDot, make sure your text cursor is in the 'block' of code
# (sections of text not separated by blank lines) and press Ctrl+Return

# To execute just a single line, even in a block, press Alt+Return

# Try it now, move the cursor to the line of code below and press Ctrl+Return

print("Hello World")

##############
# Help

# If you're ever stuck, or want to know more about a function or class
# just type help followed by the name of that Python object in brackets:

help(object)
