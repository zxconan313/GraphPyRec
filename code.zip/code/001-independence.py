# These tests simply check that some modules can be imported.

instance.unittest("base", ["independence"])
instance.unittest("dbutils", ["independence"])
instance.unittest("textutils", ["independence"])
instance.unittest("htmlutils", ["independence"])
instance.unittest("operation", ["independence"])
instance.unittest("extensions", ["independence"])
